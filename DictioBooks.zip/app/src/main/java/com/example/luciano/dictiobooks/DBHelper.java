package com.example.luciano.dictiobooks;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Luciano on 06/03/2017.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "books.db";

    public static final String BOOKS_TABLE_NAME = "books";
    public static final String BOOK_ID = "book_id";
    public static final String BOOK_TITLE = "book_title";
    public static final String BOOK_AUTHOR = "book_author";
    public static final String BOOK_GENDER = "book_genere";
    public static final String BOOK_EDITORIAL = "book_editorial";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table books " +
                        "(book_id integer,book_title text,book_author text,book_genere text,book_editorial text, PRIMARY KEY (book_id))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS books");
        onCreate(db);
    }

    //----------------------BOOKS------------------------------------------------------------------
    public boolean insertBook(String book_title, String book_author, String book_genere, String book_editorial) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("book_title", book_title);
        contentValues.put("book_author", book_author);
        contentValues.put("book_genere", book_genere);
        contentValues.put("book_editorial", book_editorial);
        db.insert("books", null, contentValues);
        return true;
    }

    public ArrayList findBookTitle(String book_title) {
        ArrayList<String> array_list = new ArrayList<String>();

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "select * from books where book_title = '" + book_title + "'";
        Cursor res = db.rawQuery(query, null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex(BOOK_TITLE)));
            res.moveToNext();
        }
        return array_list;
    }

    public ArrayList findBookEditorial(String book_editorial) {
        ArrayList<String> array_list = new ArrayList<String>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from books where book_editorial ='" + book_editorial + "'", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex(BOOK_TITLE)));
            res.moveToNext();
        }
        return array_list;
    }

    public Cursor getDataBook(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from books where book_id=" + id + "", null);
        return res;
    }

    public int numberOfRowsBook() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, BOOKS_TABLE_NAME);
        return numRows;
    }

    public ArrayList<String> getAllBooks() {
        ArrayList<String> array_list = new ArrayList<String>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from books", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex(BOOK_TITLE)));
            res.moveToNext();
        }
        return array_list;
    }

}//end of class
