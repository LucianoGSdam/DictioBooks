package com.example.luciano.dictiobooks;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Luciano on 06/03/2017.
 */
public class DisplayBook extends Activity {
    int from_Where_I_Am_Coming = 0;
    private DBHelper mydb ;

    TextView book_title;
    TextView book_author;
    TextView book_gender;
    TextView book_editorial;
    TextView book_sinopsis;
    int id_To_Update = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_book);
        book_title = (TextView) findViewById(R.id.editTextTitle);
        book_author = (TextView) findViewById(R.id.editTextAuthor);
        book_gender = (TextView) findViewById(R.id.editTextGender);
        book_editorial = (TextView) findViewById(R.id.editTextEditorial);

        mydb = new DBHelper(this);

        Bundle extras = getIntent().getExtras();
        if(extras !=null) {
            int Value = extras.getInt("id");

            if(Value>0){
                //means this is the view part not the add contact part.
                Cursor rs = mydb.getDataBook(Value);
                id_To_Update = Value;
                rs.moveToFirst();

                String tit = rs.getString(rs.getColumnIndex(DBHelper.BOOK_TITLE));
                String aut = rs.getString(rs.getColumnIndex(DBHelper.BOOK_AUTHOR));
                String gen = rs.getString(rs.getColumnIndex(DBHelper.BOOK_GENDER));
                String edit = rs.getString(rs.getColumnIndex(DBHelper.BOOK_EDITORIAL));
                if (!rs.isClosed())  {
                    rs.close();
                }
                Button b = (Button)findViewById(R.id.button1);
                b.setVisibility(View.INVISIBLE);

                book_title.setText((CharSequence)tit);
                book_title.setFocusable(false);
                book_title.setClickable(false);

                book_author.setText((CharSequence)aut);
                book_author.setFocusable(false);
                book_author.setClickable(false);

                book_gender.setText((CharSequence)gen);
                book_gender.setFocusable(false);
                book_gender.setClickable(false);

                book_editorial.setText((CharSequence)edit);
                book_editorial.setFocusable(false);
                book_editorial.setClickable(false);
            }
        }
    }

    public void run(View view) {
        if(mydb.insertBook(book_title.getText().toString(), book_author.getText().toString(),
                book_gender.getText().toString(), book_editorial.getText().toString())){
            Toast.makeText(getApplicationContext(), "done",
                    Toast.LENGTH_SHORT).show();
        } else{
            Toast.makeText(getApplicationContext(), "not done",
                    Toast.LENGTH_SHORT).show();
        }
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }
}
