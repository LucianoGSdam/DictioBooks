package com.example.luciano.dictiobooks;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Luciano on 06/03/2017.
 */
public class Libraries extends Activity implements View.OnClickListener {

    public String direccion = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommended_layout);
        TextView library1 = (TextView) findViewById(R.id.libary1);
        TextView library2 = (TextView) findViewById(R.id.libary2);
        TextView library3 = (TextView) findViewById(R.id.libary3);

        library1.setOnClickListener(this);
        library2.setOnClickListener(this);
        library3.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.libary1:
                direccion = "http://www.quars-llibres.com/";
                irAWeb(direccion);
                break;
            case R.id.libary2:
                direccion = "http://www.agapea.com/";
                irAWeb(direccion);
                break;
            case R.id.libary3:
                direccion = "http://www.libreriainglesa.com/";
                irAWeb(direccion);
                break;
            default:
                break;
        }
    }

    public void irAWeb(String url){
        Uri uri = Uri.parse(url);
        Intent intentNav = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intentNav);
    }
}


